import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { DashboardService } from '../dashboard.service';
import { covidData } from '../data';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  covidData: any[]=[];
  today = new Date().getDate();
  yesterday = new Date().getDate()-1;

  public dataSource: any[]= [];

  displayedColumns: string[] = [
    "Date", "State", "PositiveCases", "TotalDeath","Hospitalized"
  ]
  
  constructor(private dashboardService: DashboardService) { 
    Object.assign(this,{covidData});
    this.dataSource=this.covidData  
  }

  ngOnInit(): void {
    // this.dashboardService.getCovidData().subscribe((data) => {
    //   if (data){
    //     this.covidData = data;
    //   }
    // })
  }

}
