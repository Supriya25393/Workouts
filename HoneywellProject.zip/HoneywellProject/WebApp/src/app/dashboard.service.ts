import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http:HttpClient) { }

  getCovidData(): Observable<any> {
    return this.http.get('https://api.covidtracking.com/v1/states/current.json');
  }
}

